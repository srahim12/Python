#importing urlopen function
from urllib.request import urlopen as uReq

#importing beautifulsoup library
from bs4 import BeautifulSoup as soup

#dictionary library
from collections import defaultdict


#NBA Stats Scraper
#Programmed By: Shah Rahim

#Extracts the name of the player from the a tag
def getName(url):
    return url.text
    
#Returns the url of the season page on ESPN
def getUrl(base_url, season):
    if(season<10):
        new_url = base_url + str(0)+ str(season)
    else:
        new_url = base_url + str(season)
    return new_url

#Creates a filename string for each season
def getFile(season):
    if(season<10):
        filename = "season_" + str(0)+ str(season)+".csv"
    else:
        filename = "season_" + str(season)+".csv"
    return filename

#Gets the players home page url
def getPlayerUrl(url):
    str_url = str(url)
    start_pt = str_url.find("\"")
    end_pt = str_url.find("\"", start_pt + 1)
    player_url = str_url[start_pt+1:end_pt]
    return player_url

#Beautiful Soup api used to make requests and download contents of a page
def getReq(url):
    uClient = uReq(url)
    page_html = uClient.read()
    uClient.close()
    page_soup = soup(page_html,"html.parser")
    return page_soup

#Converts season i index into year string
def getYear(year):
    if(year<10):
        return '0'+str(year)
    else:
        return str(year)

def getPos(tag):
    text_len = len(tag.text)
    if(tag.text[-1]=="C"):
        return "C"
    else:
        return tag.text[-2:]

def getHgt(tag):
    loop = True
    i = 0
    while(loop):
        if(tag.text[i]==','):
            break
        i = i + 1
    return tag.text[0:i]

def getAge(tag,i):
    
    age = int(tag.text[-3:-1])
    season_age = age-(17-i)
    return(season_age)
    
def isVetPlayer(player_name):
    if(player_name=="Kobe Bryant" or player_name =="Amar'e Stoudemire" or
       player_name =="Allen Iverson" or player_name == "Chris Bosh" or
       player_name =="Yao Ming" or player_name =="Danny Granger" or
       player_name == "David Lee" or player_name =="Deron Williams"):
        return True
    return False

def getWgt(tag):
    return(tag.text[-7:-4])

#Scrapes all of the info from the players stats page
def getInfo(player_tag,i, mvp,mvp_year):
    player_url = getPlayerUrl(player_tag)
    
    player_name = getName(player_tag)
    print(player_name)
    if(i==18 and player_name=="Kevin Durant"):
        print(player_url)
    player_home = getReq(player_url)
    player_stats_tag = player_home.find("p",{"class":"footer"})                
    player_bio_container = player_home.find("div",{"class":"player-bio"}).findAll("li")

    pos_tag = player_bio_container[0]
    hgt_tag = player_bio_container[1]
    age_tag = player_bio_container[3]

    player_pos = getPos(pos_tag)
    player_hgt = getHgt(hgt_tag)
    player_wgt = getWgt(hgt_tag)
    if(isVetPlayer(player_name)):
        player_age = getAge(player_bio_container[2],i)
    else:
        player_age = getAge(age_tag,i)
    
    player_stats_url = "http://www.espn.com"+getPlayerUrl(player_stats_tag.a)
    
    player_stats_page = getReq(player_stats_url)
    player_stats_container = player_stats_page.findAll("table",{"class":"tablehead"})
    testy = player_stats_container[0].findAll("td")
    
    loop = True
    l = 21
    info = [0]* 25
    while(loop):
        if(testy[l].text=="Career"):
            break
        if(testy[l].text[5:] =="18"):
            player_team_url = testy[l+1].findAll("li")
            player_team = player_team_url[1].text
            break
        elif(testy[l].text[5:]==getYear(i)):
            print(testy[l].text)
            player_team_url = testy[l+1].findAll("li")
            if(player_name=="Deron Williams"):
                player_team = "UTAH"
            elif(player_name=="Kevin Durant" or player_name=="Chris Paul"):
                if(player_name=="Chris Paul" and i ==16):
                    player_team="LAC"
                else:
                    try:
                        player_team = player_team_url[1].text
                    except IndexError:
                        print("Testing Kevin Durant 18" + player_team_url[0].text)
                        player_team = player_team_url[0].text
            else:
                player_team = player_team_url[1].a.text
            break
        

        l = l + 20
    print(player_team)
    info[0] = player_name
    info[1] = player_pos
    info[2] = player_hgt
    info[3] = str(player_age)
    info[4] = str(player_wgt)
    info[5] = player_team
    info[6] = ""
    z =7    
    for x in range(l+2,l+20):
        info[z] = testy[x].text
        z = z + 1
    return info

#Creates a Csv format string for the players stats
def getPlayerCsvFormat(info):
    csv_format = ""
    for i in range(0,25):
        if(i == 24):
            csv_format = csv_format + info[i] + "\n"
            break
        else:
            csv_format = csv_format + info[i] + ","
    return csv_format

def getTeams(league_standings_page):
    league_standings_html = getReq(league_standings_page)
    league_team_container = league_standings_html.findAll("table",{"class":"Table2__table-scroller Table2__table-fixed Table2__Table--fixed--left Table2__table"})[0].findAll("tbody",{"class":"Table2__tbody"})[0].findAll("span",{"class":"dn show-mobile"})
    return league_team_container

def getTeamStats(league_standings_page):
    league_standings_html = getReq(league_standings_page)
    team_stats_container = league_standings_html.findAll("tbody",{"class":"Table2__tbody"})[1].findAll("tr")
    return team_stats_container

def appendDict(d,key,stats):
    for i in stats:
        d[key].append(i)
    return d

def getTeamPage(base_team_url,year):
    return base_team_url +getYear(year)+"/group/league"

def getTeamCsvFormat(key,values):
    csv_format = ""
    csv_format = csv_format + key + ","
    for i in range(0,12):
        if(i == 11):
            csv_format = csv_format + values[i] + "\n"
            break
        else:
            csv_format = csv_format + values[i] + ","
    return csv_format
    
#Main function
def main():
    #Set-Location "/path"
    #Import-Csv yourfile.csv |Out-GridView
    #Import-Csv yourfile.csv |Format-Table -AutoSize
    base_url = 'http://www.espn.com/nba/seasonleaders/_/league/nba/year/20'
    mvp_url = 'http://www.espn.com/nba/history/awards/_/id/33'
    mvp_page = getReq(mvp_url)
    mvp_container = mvp_page.find("table",{"class":"tablehead"}).findAll("td")
    base_team_url = 'http://www.espn.com/nba/standings/_/season/20'
    mvp_file = "mvp.csv"
    mf = open(mvp_file,"w")
    mvp_header = "Year, Name, POS, HGT, Age, WGT, Team, W-L, GP, GS, Min, FGM-A, FG%, 3PM-A,3P%, FTM-A, FT%, OR, DR, REB, AST, BLK, STL, PF, TO, PTS\n"
    mf.write(mvp_header)
    
    mvp_y = 10
    mvp_n = 11
    mvp_list = [0]*10
    mvp_year = [0]*10
    index = 0
    while(index<10):
        mvp_list[index]=mvp_container[mvp_n].text
        mvp_year[index]=mvp_container[mvp_y].text
        index = index + 1
        mvp_n = mvp_n + 9
        mvp_y = mvp_y + 9
              
    mvp_list.reverse()
    mvp_year.reverse()
    i = 8
    mvp_y = 0
    mvp_n = 0
    test = True
    while (i<=18):
        player_season_filename = getFile(i)
        f = open(player_season_filename,"w")
        player_name_header = "Name, POS, HGT, Age, WGT, Team, W-L, GP, GS, Min, FGM-A, FG%, 3PM-A,3P%, FTM-A, FT%, OR, DR, REB, AST, BLK, STL, PF, TO, PTS\n"
        f.write(player_name_header)
        
        season_url = getUrl(base_url,i)
        print("")
        print("Season: " + getYear(i))
        page_soup = getReq(season_url)
        container_odd = page_soup.findAll("tr",{"class":"oddrow"})
        container_even = page_soup.findAll("tr",{"class":"evenrow"})
        j = 0
        player_even = 0
        player_odd = 0
        
        team_standings_filename = "team_"+getFile(i)
        tf = open(team_standings_filename,"w")
        team_standings_header = "Team, W, L, PCT, GB, HOME, AWAY, DIV, CONF, PPG, OPP-PPG, DIFF, STRK\n"
        tf.write(team_standings_header)
        league_standings_page = getTeamPage(base_team_url,i)
        league_team_container = getTeams(league_standings_page)
        team_stats_container = getTeamStats(league_standings_page)

        d = defaultdict(list)
        k = 0
        for l in league_team_container:
            if l.a is None: 
                key = l.abbr.text
            else:
                key = l.a.text
            for m in team_stats_container[k].findAll("td"):
                d[key].append(m.text)
            k+=1
            tf.write(getTeamCsvFormat(key,d.get(key)))
        while (j < 10):
            if (j%2!=0):
                player_tag = container_even[player_even].a
                
                info = getInfo(player_tag,i,0,0)
                info[6] = d.get(info[5])[0] + "-" + d.get(info[5])[1]
                csv_row = getPlayerCsvFormat(info)
                if(i<18):
                    if(info[0]==mvp_list[mvp_n] and mvp_year[mvp_y][3]==getYear(i)[1]):
                        print(info[0]+ " is the MVP for: " +mvp_year[mvp_y])
                        mf.write(mvp_year[mvp_y]+","+csv_row)
                f.write(csv_row)
                player_even = player_even + 1
            else:
                player_tag = container_odd[player_odd].a
                info = getInfo(player_tag,i,0,0)
                info[6] = d.get(info[5])[0] + "-" + d.get(info[5])[1]
                csv_row = getPlayerCsvFormat(info)
                if(i<18):
                    if(info[0]==mvp_list[mvp_n] and mvp_year[mvp_y][3]==getYear(i)[1]):
                        print(info[0]+ " is the MVP for: " +mvp_year[mvp_y])
                        mf.write(mvp_year[mvp_y]+","+csv_row)
                f.write(csv_row)
                player_odd = player_odd + 1
            j = j + 1
    
        f.close()
        mvp_n = mvp_n + 1
        mvp_y = mvp_y + 1
        i = i + 1
    
main()
